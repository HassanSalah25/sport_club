<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TournamentPlayersDetails extends Model
{
    use HasFactory;
//    protected $table='tournament_players_details';

    protected $guarded=[];
}
