<?php

namespace App\Enum;

class ReceiptTypes
{
public $Types = [

];
}
